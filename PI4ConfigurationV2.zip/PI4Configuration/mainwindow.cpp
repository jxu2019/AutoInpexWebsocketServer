#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QDateTime>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    try{
    ui->setupUi(this);

    QFile inputFile("/home/pi/AutoInspex_Config.txt");
    if (inputFile.open(QIODevice::ReadOnly))
    {
       QTextStream in(&inputFile);
       while (!in.atEnd())
       {
          QString line = in.readLine();
          QRegExp tagExp(":");
          QStringList firstList = line.split(tagExp);
          QString ss = firstList[0];
          map.insert(firstList[0],firstList[1]);
       }
       inputFile.close();
    }
    if (map.contains("SerialNumber"))
        ui->SerialNumber->setText(map.value("SerialNumber"));
    if (map.contains("SensorID"))
        ui->SensorID->setText(map.value("SensorID"));
    if (map.contains("LensID"))
        ui->LensID->setText(map.value("LensID"));
    if (map.contains("FabName"))
        ui->FabName->setText(map.value("FabName"));
    if (map.contains("FabName"))
        ui->SDModel_ID->setText(map.value("SDModel_ID"));
    if (map.contains("FabName"))
        ui->CaseID->setText(map.value("CaseID"));
    if (map.contains("FabName"))
        ui->shoeID->setText(map.value("ShoeID"));
    if (map.contains("FabDate")){
        QDate date = QDate::fromString(map.value("FabDate"),"MM/dd/yyyy") ;
        ui->FabDate->setDate(date);
    }else{
         ui->FabDate->setDateTime(QDateTime::currentDateTime());
    }
    }
    catch (...)
    {


    }
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    QMetaObject::invokeMethod(this, "close",
        Qt::QueuedConnection);
}

void MainWindow::showWarning(const QString &title, const QString &message)
{
    QMessageBox msgBox(this);
    msgBox.setText(message);
    msgBox.setWindowTitle(title);
    msgBox.setWindowFlags(Qt::Window );     // add minimize button
    msgBox.setWindowFlags(msgBox.windowFlags()&(~Qt::WindowMinimizeButtonHint)); // remove minimize button
    msgBox.setWindowFlags(msgBox.windowFlags()&(~Qt::WindowMaximizeButtonHint)); // remove minimize button
    msgBox.setIcon(QMessageBox::Warning);
    msgBox.setFixedSize(QSize(300, 50));
    msgBox.exec();
}
void MainWindow::on_pushButton_2_clicked()
{
     try{
    if(ui->SerialNumber->toPlainText()=="")
    {
        showWarning( "PI Configuration", "Serial number is required. Please enter serial number!");
        return;
    }
    if(ui->SensorID->toPlainText()=="")
    {
        showWarning("PI Configuration", "Sensor ID is required. Please enter sensor ID!");
        return;
    }
    if(ui->SDModel_ID->toPlainText()=="")
    {
        showWarning("PI Configuration", "SD Model ID is required. Please enter lense ID!");
        return;
    }
    if(ui->LensID->toPlainText()=="")
    {
        showWarning("PI Configuration", "lense ID is required. Please enter lense ID!");
        return;
    }
    if(ui->CaseID->toPlainText()=="")
    {
        showWarning("PI Configuration", "Case ID is required. Please enter lense ID!");
        return;
    }
    if(ui->shoeID->toPlainText()=="")
    {
        showWarning("PI Configuration", "Shoe ID is required. Please enter lense ID!");
        return;
    }

    map["SerialNumber"]=ui->SerialNumber->toPlainText();
    map["LensID"]=ui->LensID->toPlainText();
    map["SensorID"]=ui->SensorID->toPlainText();
    map["FabName"]=ui->FabName->toPlainText();
    map["FabDate"]=ui->FabDate->date().toString("MM/dd/yyyy");
    map["SDModel_ID"]=ui->SDModel_ID->toPlainText();
    map["CaseID"]=ui->CaseID->toPlainText();
    map["ShoeID"]=ui->shoeID->toPlainText();

    QFile file("/home/pi/AutoInspex_Config.txt");
    if (!file.open(QIODevice::WriteOnly| QIODevice::Text))
       return;
     QTextStream out(&file);
     QMap<QString, QString>::const_iterator i = map.constBegin();
     while (i != map.constEnd()) {
         out << i.key() << ":" << i.value() << "\n";
         ++i;
     }
     file.close();
     QMessageBox msgBox(this);
     msgBox.setText("PI Configuration data has been successfully saved.");
     msgBox.setWindowTitle("PI Configuration");
     msgBox.setWindowFlags(Qt::Window );     // add minimize button
     msgBox.setWindowFlags(msgBox.windowFlags()&(~Qt::WindowMinimizeButtonHint)); // remove minimize button
     msgBox.setWindowFlags(msgBox.windowFlags()&(~Qt::WindowMaximizeButtonHint)); // remove minimize button
     msgBox.setIcon(QMessageBox::Information);
     msgBox.setFixedWidth(300);
     msgBox.exec();
     QMetaObject::invokeMethod(this, "close",
         Qt::QueuedConnection);
    }
    catch (...)
    {


    }
}
